"""Persistence helpers for fixed-supported Equelo ratings."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from src.analysis.equelo.expt1.simulate import RatingsByDate
from src.sumo_core.Chii import Chii
from src.sumo_core.History import History

from .model import (
    DAY_END_RATINGS_FILE_NAME,
    ENTRANT_INITIAL_RATINGS_FILE_NAME,
    METADATA_FILE_NAME,
    MODEL_VERSION,
    OUTPUT_ROOT,
    policy_metadata,
)


def write_outputs(
    *,
    history: History,
    day_end_ratings: RatingsByDate,
    entrant_initial_ratings: dict[Chii, float],
    output_root: Path = OUTPUT_ROOT,
    model_metadata_overrides: dict[str, object] | None = None,
) -> dict[str, Path]:
    """Write day-end ratings, chii initial ratings, and metadata."""

    output_root.mkdir(parents=True, exist_ok=True)
    ratings_path = output_root / DAY_END_RATINGS_FILE_NAME
    entrant_path = output_root / ENTRANT_INITIAL_RATINGS_FILE_NAME
    metadata_path = output_root / METADATA_FILE_NAME

    ratings_payload = serialise_day_end_ratings(day_end_ratings)
    write_json(ratings_path, ratings_payload)

    entrant_payload = serialise_entrant_initial_ratings(entrant_initial_ratings)
    write_json(entrant_path, entrant_payload)

    write_json(
        metadata_path,
        build_metadata(
            history=history,
            day_end_ratings=ratings_payload,
            entrant_initial_ratings=entrant_payload,
            model_metadata_overrides=model_metadata_overrides,
        ),
    )
    return {
        "metadata": metadata_path,
        "day_end_ratings": ratings_path,
        "entrant_initial_ratings": entrant_path,
    }


def serialise_day_end_ratings(
    day_end_ratings: RatingsByDate,
) -> dict[str, dict[str, dict[str, float]]]:
    """Convert simulator day-end ratings to JSON-serialisable nested dicts."""

    payload: dict[str, dict[str, dict[str, float]]] = {}
    for date in sorted(day_end_ratings.keys()):
        date_key = str(date)
        payload[date_key] = {}
        for day in sorted(day_end_ratings[date].keys()):
            payload[date_key][str(int(day))] = {
                str(int(rikishi_id)): rating
                for rikishi_id, rating in sorted(
                    day_end_ratings[date][day].items(),
                    key=lambda item: int(item[0]),
                )
            }
    return payload


def serialise_entrant_initial_ratings(
    entrant_initial_ratings: dict[Chii, float],
) -> dict[str, float]:
    """Convert the chii initial-rating map to an ordinal-keyed JSON payload."""

    return {
        str(chii.ordinal()): rating
        for chii, rating in sorted(
            entrant_initial_ratings.items(),
            key=lambda item: item[0].ordinal(),
        )
    }


def build_metadata(
    *,
    history: History,
    day_end_ratings: dict[str, dict[str, dict[str, float]]],
    entrant_initial_ratings: dict[str, float],
    model_metadata_overrides: dict[str, object] | None = None,
) -> dict[str, object]:
    """Build metadata for a fixed-supported output set."""

    dates = sorted(history.keys())
    rating_points = sum(len(days) for days in day_end_ratings.values())
    rating_count = sum(
        len(ratings)
        for days in day_end_ratings.values()
        for ratings in days.values()
    )
    model = policy_metadata()
    if model_metadata_overrides:
        model.update(model_metadata_overrides)

    return {
        "model_version": MODEL_VERSION,
        "generated_at": datetime.now().astimezone().isoformat(),
        "history_min_date": str(dates[0]),
        "history_max_date": str(dates[-1]),
        "history_basho_count": len(dates),
        "rating_points": rating_points,
        "rating_count": rating_count,
        "entrant_initial_rating_count": len(entrant_initial_ratings),
        "model": model,
    }


def write_json(path: Path, payload: object) -> None:
    """Write consistently formatted JSON."""

    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
