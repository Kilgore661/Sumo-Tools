# Rendering Change Review - 03 Design Classification

## 3. First-Pass Design Classification

The proposed change set is understandable and mostly precise enough to begin
design work. It should not be implemented as an undifferentiated CSS pass.

The subsections below classify each proposed change by ownership and
implementation impact. Section 4 then groups the work into likely implementation
streams.

### 3.1 Help/popover marker URL state

The visible info-here marker is no longer primarily a production/development
split. It is proposed as an explicit URL-selected diagnostic mode owned by the
public/runtime state layer:

```text
debug_show_notes=true
```

This is a runtime presentation-state feature. It should be treated similarly to a
reader/reviewer display mode: absent or false hides the indicator; true shows it.

The `--prod` question remains separate. `--prod` may or may not imply removal of
stylistic debugging features, but that is an open build-mode policy decision and
should not be assumed by the `debug_show_notes` design.

### 3.2 Table heading spacing

This is shared table/PA-caption rendering policy. It belongs to table-like PA
presentation and/or PA caption spacing, not to the Public UI Model.

### 3.3 Interim table structure and column groups

The table structure requests were deliberately narrower than a general table
model. The implemented approach uses interim, explicit metadata for the reviewed
non-7.1 column-group cases and does not migrate ordinary tables into the
recursive table model.

Status: resolved for the current table model and shared renderers. If a later
general table model is adopted, the interim metadata can be revisited.

### 3.4 Table border and column-group policy

The general table bounding box, lowest-heading underline and suppression of other
grid lines are shared table rendering policy.

Column-group boundary lines require explicit column-group knowledge. For 7.1
Basho Results, that knowledge is already model-driven by the recursive/grouped
table structure. For tables other than 7.1, the current implementation uses
explicit declarations. The default remains “no groups here”; individual flat
columns do not automatically imply column groups.

Status: resolved for the reviewed slice.

### 3.5 Alternating row colours

This is theme/token tuning inside an already accepted shared table rule.

Status: implemented for the reviewed slice.

### 3.6 Shikona links

This is runtime interaction and public-link policy, not styling. It should be
implemented as shared shikona-link semantics so all table renderers behave
consistently.

Status: implemented.

### 3.7 Basho selector redesign

This was implemented as a PA-specific Basho Results runtime control inside the
existing `FilterSection`, rather than as a general new filter-control model.

The implementation changes the control from a single finite basho selector into
a compound Basho block with Year and Month dropdowns plus navigation buttons. The
public URL state is `year` and `month`. Legacy basho date parameters are treated
as compatibility input where practical.

Valid no-basho states are supported only for supported sumo years and the six
sumo months. Invalid URL handling remains a separate routing concern.

Status: implemented.

### 3.8 Section 9.1 vertically spanning headings

This is resolved by the interim 9.1 column-group declaration. If a later general
table model is adopted, this rule can be revisited.

Status: resolved for the current table model.

### 3.9 Muted foreground colour

This is a shared theme token carrying semantic meaning where used.

Status: resolved for the reviewed slice. Mechanical row numbers use the muted
foreground token. Broader uses of a muted token should be handled only when a new
concrete requirement arises.

### 3.10 Row-number column on all tables

This is table model/rendering policy, not merely CSS.

Status: resolved for the current table model and reviewed table set. A distinct
mechanical `row_number` column now has blank heading, muted treatment, non-sort
semantics and sort/filter recomputation where applicable in 7.1, 7.4-style
generic tables, 9.1 and Banzuke Changes 2.1. In 2.1, the banzuke-style view
treats row number as a leading blank group/header spanning the East/Rank/West
heading depth, while the scan-table view treats it as a flat leading non-sortable
column.

### 3.11 Superlative tables and ordinal/ranking columns

This is part of the same row-number/ranking policy.

Status: resolved for the current table model and reviewed table set. The `#`
ranking column is treated separately from mechanical row numbers. Career Length
Longest uses produced ranks rather than runtime-derived rank.

### 3.12 Date separator

This is a shared data-formatting/rendering rule for date-like values in public
rendered display. It should not be assumed to change source data, CSV contracts,
filenames, URL parameters, internal identifiers or other non-display contexts
where `/` is normal unless a later requirement says so.

Status: implemented for known table and chart display points in the reviewed
slice.

### 3.13 Popovers that mention Notes

This is runtime interaction/state plus a text-triggered popover action rule. The
qualifying condition is exact text occurrence of `Notes`; the whole popover owns
the click.

Status: implemented for Notes popovers. Notes validation/tightening remains TBD.

### 3.14 Conditional x-axis tick rotation

This is shared chart rendering policy.

Status: resolved for the reviewed simple charts. Dense-axis cases now either let
Plotly choose angle/density directly or carry a local density hint where the chart
requires it. 3.3 Rikishi History remains a separate follow-up.

### 3.15 Bold axis titles

This is a shared Plotly chart presentation rule.

Status: implemented and moved into rendering design.

### 3.16 Specific charts should be line charts

This is a product/PA-form change, not CSS. It changes the PA terminal form or
chart renderer choice, and should be checked against the public analytical
question because bar/column charts and line charts make different claims.

Status: implemented for the reviewed PA-specific charts. 3.3 Rikishi History
remains a separate follow-up.

### 3.17 Section 6.3.1 error bars

This is a PA-specific chart rendering rule. Because error bars communicate
uncertainty, the colour choice belongs to that PA feature.

Status: implemented for the reviewed chart.

### 3.18 Career Length Longest active filter

This is PA-specific chart/table semantics for 7.3.1, not a generic filter model
change. The implementation materializes ranked Longest populations from producer
spans and lets runtime switch between those produced populations. `Show Active`
is a Longest-only dependent option.

Status: implemented. Checked/default true includes active rikishi; unchecked
shows the non-active population. Active Last values display as `-`.

### 3.19 Section 6.2.1 sectioned-table layout

This is a PA-specific/custom sectioned table layout. It is not evidence that
ordinary tables should move to a recursive table model.

Status: implemented for the reviewed slice.